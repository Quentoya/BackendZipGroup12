package GoCars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Group12GoCarsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Group12GoCarsApplication.class, args);
	}

}
